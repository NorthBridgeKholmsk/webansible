function addVar(){
    const varList = document.getElementById("vars")
    varList.innerHTML += '<div class="row field form-group mb-3"><div class="col"><input type="text" class="form-control"></div><div class="col"><input type="text" class="form-control"></div><div type="button" class="col-md-auto p-0"><button class="bg-opacity-100 border-0 bi bi-x-circle text-danger btn m-0 p-0 pe-3 h1"></button></div></div>'
}

function delVar(){

};
