function menuTurn(){
    alert("test");
};
