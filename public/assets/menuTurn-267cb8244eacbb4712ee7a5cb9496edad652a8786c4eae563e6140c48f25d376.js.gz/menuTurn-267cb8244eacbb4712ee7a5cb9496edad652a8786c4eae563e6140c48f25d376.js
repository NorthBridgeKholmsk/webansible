function menuTurn(){
    document.getElementById("logo_img").style.display = "none";
};
