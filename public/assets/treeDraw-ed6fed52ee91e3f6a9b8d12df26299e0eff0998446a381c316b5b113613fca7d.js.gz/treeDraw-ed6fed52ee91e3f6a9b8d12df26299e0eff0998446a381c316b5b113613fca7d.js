function draw(hash){
    document.getElementById("dirTree").innerText = <p>TECT</p>
};
