function menuTurn(){
    alert(document.getElementById("logo_img").style.display);
    document.getElementById("logo_img").style.display = "none";
};
