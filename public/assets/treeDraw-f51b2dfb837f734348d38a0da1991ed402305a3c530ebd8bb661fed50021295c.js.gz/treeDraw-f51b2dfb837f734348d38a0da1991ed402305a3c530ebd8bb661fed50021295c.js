document.addEventListener("DOMContentLoaded", function(){
    draw("");
});

function draw(hash){
    document.getElementById("dirTree").innerText = "<p>TECT</p>"
};
